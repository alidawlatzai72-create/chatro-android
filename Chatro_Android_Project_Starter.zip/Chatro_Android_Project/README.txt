CHATRO ANDROID PROJECT — STARTER SHELL

What this project currently does:
- Opens the existing Chatro Netlify app inside an Android WebView.
- Exposes a native JavaScript bridge named `ChatroNative`.
- The bridge can open Android's official screen-capture consent dialog.
- Sends a consent result event back into the web page.

What this project does NOT do yet:
- It does not capture frames into an Android WebRTC VideoTrack.
- It does not add that track to Chatro's existing RTCPeerConnection.
- It does not send screen video to the other caller.
- Therefore this is NOT a working screen-sharing release or a finished APK.

Why the remaining work matters:
Chatro's current HTML uses browser RTCPeerConnection for calls. Native MediaProjection
permission alone is not a MediaStream and cannot be passed into that JavaScript peer
connection. A native WebRTC capture track and a bridge/integration with the existing
call signaling and peer-connection lifecycle are still needed. Android 14+ also has
specific foreground-service requirements for active media projection sessions.

Open:
1. Install Android Studio on a computer.
2. Choose Open and select this Chatro_Android_Project folder.
3. Let Gradle sync. Use JDK 17 and Android SDK 35.
4. Build > Build APK(s) only after Gradle sync succeeds.

The app URL is set in app/src/main/java/com/chatro/app/MainActivity.java as CHATR0_URL.
If your Netlify address changes, update that constant.

The original Chatro HTML is not modified by this starter project.
