package com.chatro.app;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/** Android WebView shell for the existing Chatro web app.
 * Screen-capture consent is wired as a native entry point. The resulting
 * MediaProjection is deliberately NOT treated as a WebRTC stream: connecting
 * it to Chatro's existing Supabase/WebRTC call negotiation is a separate task.
 */
public class MainActivity extends Activity {
    private static final int REQUEST_SCREEN_CAPTURE = 4207;
    private static final String CHATR0_URL = "https://lighthearted-flan-8c56d2.netlify.app/";
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(android.webkit.PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });
        webView.addJavascriptInterface(new ChatroBridge(), "ChatroNative");
        webView.loadUrl(CHATR0_URL);
    }

    private final class ChatroBridge {
        @JavascriptInterface public void requestScreenCapture() {
            runOnUiThread(() -> {
                MediaProjectionManager manager =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                if (manager == null) {
                    Toast.makeText(MainActivity.this, "Screen capture is unavailable on this device.", Toast.LENGTH_LONG).show();
                    return;
                }
                startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_SCREEN_CAPTURE) return;
        if (resultCode == RESULT_OK && data != null) {
            // Consent was granted. Do not claim sharing has started: no native
            // WebRTC VideoTrack is connected to Chatro's remote call yet.
            Toast.makeText(this,
                "Screen-capture permission granted. Call streaming integration is still required.",
                Toast.LENGTH_LONG).show();
            if (webView != null) webView.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent('chatro-native-screen-capture-consent',{detail:{granted:true}}));", null);
        } else {
            if (webView != null) webView.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent('chatro-native-screen-capture-consent',{detail:{granted:false}}));", null);
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
